/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

/**
 * @module font/fontcolor/fontcolorediting
 */

import Plugin from '@ckeditor/ckeditor5-core/src/plugin';
import FontColorCommand from './fontcolorcommand';
import { FONT_COLOR, renderDowncastElement, renderUpcastAttribute } from '../utils';

/**
 * The font color editing feature.
 *
 * It introduces the {@link module:font/fontcolor/fontcolorcommand~FontColorCommand command} and
 * the `fontColor` attribute in the {@link module:engine/model/model~Model model} which renders
 * in the {@link module:engine/view/view view} as a `<span>` element (`<span style="color: ...">`),
 * depending on the {@link module:font/fontcolor~FontColorConfig configuration}.
 *
 * @extends module:core/plugin~Plugin
 */
export default class FontColorEditing extends Plugin {
	/**
	 * @inheritDoc
	 */
	constructor( editor ) {
		super( editor );

		editor.config.define( FONT_COLOR, {
			colors: [
				{
					color: 'hsl(0, 0%, 0%)',
					label: 'Black'
				},
				{
					color: 'hsl(0, 0%, 30%)',
					label: 'Dark Grey'
				},
				{
					color: '#5d5d5d',
					label: '默认字体色'
				},
				{
					color: '#808080',
					label: '默认灰色字体色'
				},
				{
					color: '#8e8e8e',
					label: '夜间模式默认字体颜色'
				},
				{
					color: 'hsl(0, 0%, 90%)',
					label: 'Light grey'
				},
				{
					color: 'hsl(0, 0%, 100%)',
					label: 'White',
					hasBorder: true
				},
				{
					color: '#800000',
					label: '深红色强调色'
				},
				{
					color: '#8f3625',
					label: '橙色背景字体颜色'
				},
				{
					color: '#bf5f3e',
					label: '橙色'
				},
				{
					color: '#ff3b30',
					label: '气泡颜色'
				},
				{
					color: '#dc663e',
					label: '忘记色'
				},
				{
					color: '#eb9e27',
					label: '模糊色'
				},
				{
					color: '#ff6600',
					label: '橙色超链接色'
				},
				{
					color: '#0c5040',
					label: '绿色button字体色'
				},
				{
					color: '#008000',
					label: '绿色'
				},
				{
					color: '#446359',
					label: '图标页面90天曲线颜色'
				},
				{
					color: '#1e957d',
					label: '绿色标准色'
				},
				{
					color: '#82c2ab',
					label: '认识色，公告栏标题色'
				},
				{
					color: '#99cc99',
					label: '复习页面绿色字体'
				},
				{
					color: '#36e59d',
					label: '标准色主色'
				},
				{
					color: 'hsl(240, 75%, 60%)',
					label: 'Blue'
				},
				{
					color: '#5581f1',
					label: '蓝色',
				},
				{
					color: 'hsl(210, 75%, 60%)',
					label: 'Light blue'
				},
				{
					color: '#039cfc',
					label: '浅蓝色'
				},
				{
					color: '#531ef3',
					label: '紫色',
				},
				{
					color: 'hsl(270, 75%, 60%)',
					label: 'Purple'
				},
				{
					color: '#ae54d0',
					label: '紫粉色',
				}
			],
			columns: 7
		} );

		editor.conversion.for( 'upcast' ).elementToAttribute( {
			view: {
				name: 'span',
				styles: {
					'color': /[\s\S]+/
				}
			},
			model: {
				key: FONT_COLOR,
				value: renderUpcastAttribute( 'color' )
			}
		} );

		editor.conversion.for( 'downcast' ).attributeToElement( {
			model: FONT_COLOR,
			view: renderDowncastElement( 'color' )
		} );

		editor.commands.add( FONT_COLOR, new FontColorCommand( editor ) );

		// Allow the font color attribute on text nodes.
		editor.model.schema.extend( '$text', { allowAttributes: FONT_COLOR } );

		editor.model.schema.setAttributeProperties( FONT_COLOR, { isFormatting: true } );
	}
}
