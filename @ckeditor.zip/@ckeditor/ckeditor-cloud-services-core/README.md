CKEditor Cloud Services Core
============================

CKEditor Cloud Services Core API:

* Upload Gateway - API for file uploads to CKEditor Cloud Services.

## License

Licensed under the terms of [GNU General Public License Version 2 or later](http://www.gnu.org/licenses/gpl.html). For full details about the license, please check the LICENSE.md file.
